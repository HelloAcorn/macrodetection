from PIL import Image

img = Image.open("1642086118.png")
(img_x, img_y) = img.size
print(img.size)
