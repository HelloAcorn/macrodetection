import macromodule
import pyautogui
import time
import cv2


for a in range(3):
    x, y = macromodule.image_click('monster_count.png',0.8,0.5)
    pyautogui.screenshot(r'C:\Users\yoonhong\Desktop\메이플 매크로\몬스터 처치 사진\{}.png'.format(int(time.time())),
                         region = (x+106,y-9,23,18))
    time.sleep(1)
    print(a)

